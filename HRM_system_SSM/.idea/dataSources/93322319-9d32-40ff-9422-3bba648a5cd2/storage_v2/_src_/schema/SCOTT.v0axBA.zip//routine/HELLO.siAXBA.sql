create procedure hello
  as
  begin
    dbms_output.put_line('hello world');
  end;
/

