create procedure findEmp(eid in number,ename out varchar2,esalary out number)
  as
  begin
    select E_NAME,E_SALARY into ename,esalary from T_EMP where E_ID=eid;
  end;
/

