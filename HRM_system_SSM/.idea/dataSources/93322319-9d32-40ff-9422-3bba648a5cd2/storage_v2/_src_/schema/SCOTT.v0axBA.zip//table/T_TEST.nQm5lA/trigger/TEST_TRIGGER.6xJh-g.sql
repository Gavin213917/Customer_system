create trigger TEST_TRIGGER
  before insert
  on T_TEST
  for each row
  begin
    select test_seq.Nextval into :new.T_ID from dual;
  end;
/

