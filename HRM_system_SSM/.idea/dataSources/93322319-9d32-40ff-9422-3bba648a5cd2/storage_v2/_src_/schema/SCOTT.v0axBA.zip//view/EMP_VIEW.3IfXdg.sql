create view EMP_VIEW as
  select avg(E_SALARY),sum(E_SALARY) from T_EMP
/

