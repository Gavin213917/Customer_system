create procedure p_salary(pid in number)
  as
  psalary T_EMP.E_SALARY%type;
  begin
    select E_SALARY into psalary from T_EMP where E_ID=pid;
    update T_EMP set E_SALARY=E_SALARY+100 where E_ID=pid;
  end;
/

