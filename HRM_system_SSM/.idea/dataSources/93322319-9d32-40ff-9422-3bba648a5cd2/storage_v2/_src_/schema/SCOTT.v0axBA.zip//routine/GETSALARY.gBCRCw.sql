create FUNCTION getSalary(eid in number)
  return number
  as
  fSalary T_EMP.E_SALARY%type;
  begin
    select E_SALARY into fSalary from T_EMP where E_ID=eid;
    return fSalary;
  end;
/

